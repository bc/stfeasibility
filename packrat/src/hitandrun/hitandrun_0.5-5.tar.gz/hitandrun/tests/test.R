library(testthat)
library(hitandrun)
test_check('hitandrun')
