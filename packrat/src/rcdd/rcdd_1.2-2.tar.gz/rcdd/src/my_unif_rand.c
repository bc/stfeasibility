
#include <R.h>
#include "my_unif_rand.h"

double my_unif_rand(void)
{
    return unif_rand();
}

