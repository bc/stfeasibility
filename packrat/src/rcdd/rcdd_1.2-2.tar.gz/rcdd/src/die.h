
#ifndef RCDD_DIE_H
#define RCDD_DIE_H

void die(const char *format, ...);

#endif /* RCDD_DIE_H */

