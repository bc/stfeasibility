
#ifndef RCDD_MYRAND_H
#define RCDD_MYRAND_H

double my_unif_rand(void);

#endif /* RCDD_MYRAND_H */

