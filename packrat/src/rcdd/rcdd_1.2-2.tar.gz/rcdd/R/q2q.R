q2q <- function(x) .Call(C_q2q, x)
