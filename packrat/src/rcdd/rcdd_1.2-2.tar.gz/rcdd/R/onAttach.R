
.onAttach <- function(lib, pkg) {
     packageStartupMessage(
         "If you want correct answers, use rational arithmetic.\n",
         "See the Warnings sections added to help pages for\n",
         "    functions that do computational geometry.\n")
}

