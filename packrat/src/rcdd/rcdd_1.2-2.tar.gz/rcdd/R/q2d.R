q2d <- function(x) .Call(C_q2d, x)
